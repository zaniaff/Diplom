﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp123.Viws
{
    /// <summary>
    /// Логика взаимодействия для Purch.xaml
    /// </summary>
    public partial class Purch : Page
    {
        public Purch()
        {
            InitializeComponent();

            GridPurch.ItemsSource = pro12Entities6.GetContext().Zakaz.ToList();
            CmbCabinet.ItemsSource = pro12Entities6.GetContext().Department.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Add2((sender as Button).DataContext as Zakaz));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {

                pro12Entities6.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                GridPurch.ItemsSource = pro12Entities6.GetContext().Zakaz.ToList();


            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Add2(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var clientForRemoving = GridPurch.SelectedItems.Cast<Zakaz>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {clientForRemoving.Count()} элементов", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    pro12Entities6.GetContext().Zakaz.RemoveRange(clientForRemoving);
                    pro12Entities6.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    GridPurch.ItemsSource = pro12Entities6.GetContext().Zakaz.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void CmbCabinet_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void TxtFirstName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

        public void Filter()
        {
            List<Zakaz> clients = pro12Entities6.GetContext().Zakaz.ToList();

            if (CmbCabinet.SelectedItem == null && TxtFirstName.Text == "")
            {
                return;
            }

            if (CmbCabinet.SelectedItem != null)
            {
                Department CurrentGender = CmbCabinet.SelectedItem as Department;
                clients = clients.Where(z => z.Department == CurrentGender).ToList();
            }

            clients = clients.Where(z => z.Title.ToLower().Contains(TxtFirstName.Text.ToLower())).ToList();
            GridPurch.ItemsSource = clients;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BtnReport_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ReportAffers());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            CmbCabinet.SelectedValue = null;
            TxtFirstName.Text = null;

            GridPurch.ItemsSource = pro12Entities6.GetContext().Zakaz.ToList();
        }


    }
}
