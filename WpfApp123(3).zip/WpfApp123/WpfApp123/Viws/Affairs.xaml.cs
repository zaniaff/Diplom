﻿using Microsoft.Vbe.Interop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp123.Viws
{
    /// <summary>
    /// Логика взаимодействия для Affairs.xaml
    /// </summary>
    public partial class Affairs : Page
    {
        public Affairs()
        {
            InitializeComponent();
            GridDeal.ItemsSource = pro12Entities6.GetContext().Djob.ToList();
            CmbCabinet.ItemsSource = pro12Entities6.GetContext().Department.ToList();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Add3((sender as Button).DataContext as Djob));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {

                pro12Entities6.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                GridDeal.ItemsSource = pro12Entities6.GetContext().Djob.ToList();


            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Add3(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var clientForRemoving = GridDeal.SelectedItems.Cast<Djob>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {clientForRemoving.Count()} элементов", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    pro12Entities6.GetContext().Djob.RemoveRange(clientForRemoving);
                    pro12Entities6.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    GridDeal.ItemsSource = pro12Entities6.GetContext().Djob.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }


        private void DatePicr_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            Filter();
        }


        private void CmbCabinet_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void TxtFirstName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

       

        public void Filter()
        {
            List<Djob> clients = pro12Entities6.GetContext().Djob.ToList();
    
            if (CmbCabinet.SelectedItem == null && TxtFirstName.Text == "" && DatePicr.SelectedDate == null)
            {
                return;
            }

            
            if (DatePicr.SelectedDate != null)
            {
                //clients = (List<Djob>)clients.Where(eve => eve.Time == DatePicr.SelectedDate).ToList();

                clients = clients.Where(z => z.Time == DatePicr.SelectedDate).ToList();
            }

            if (CmbCabinet.SelectedItem != null)
            {
                Department CurrentGender = CmbCabinet.SelectedItem as Department;
                clients = clients.Where(z => z.Department == CurrentGender).ToList();
            }

            clients = clients.Where(z => z.Deal.ToLower().Contains(TxtFirstName.Text.ToLower())).ToList();
            GridDeal.ItemsSource = clients;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            CmbCabinet.SelectedValue = null;
            TxtFirstName.Text = null;
            DatePicr.SelectedDate = null;

            GridDeal.ItemsSource = pro12Entities6.GetContext().Djob.ToList();
        }
    }
}
