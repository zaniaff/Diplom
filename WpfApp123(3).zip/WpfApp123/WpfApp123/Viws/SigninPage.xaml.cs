﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp123.Viws
{
    /// <summary>
    /// Логика взаимодействия для SigninPage.xaml
    /// </summary>
    public partial class SigninPage : Page
    {
        string LoginText;
        public SigninPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var currentUser = pro12Entities6.GetContext().account.FirstOrDefault(u => u.FirstName == TxbLogin.Text && u.password == TxbPassword.Text );

            string LoginTxt = TxbLogin.Text.ToLower();

            if (currentUser != null)
            {

                LoginText = LoginTxt; 
                
                if (LoginText == "admin")  
                {
                    NavigationService.Navigate(new WelcomePage());
                }
                if ( LoginText == "accountant")
                {
                    NavigationService.Navigate(new Purch()); 
                }
                if (LoginText == "chapter")
                {
                    NavigationService.Navigate(new Affairs());
                }

                {

    }
                

            }
            else
            {
                MessageBox.Show("такого пользователя нет в базе");
            }


           
        }
    }
}
