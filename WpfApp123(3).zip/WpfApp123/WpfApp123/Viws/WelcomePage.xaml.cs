﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp123.Viws
{
    /// <summary>
    /// Логика взаимодействия для WelcomePage.xaml
    /// </summary>
    public partial class WelcomePage : Page
    {
        public WelcomePage()
        {
            InitializeComponent();

            GridName.ItemsSource = pro12Entities6.GetContext().name.ToList();
            CmbCabinet.ItemsSource = pro12Entities6.GetContext().Department.ToList();  
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Add1((sender as Button).DataContext as name ));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Visibility == Visibility.Visible)
            {

                pro12Entities6.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                GridName.ItemsSource = pro12Entities6.GetContext().name.ToList();


            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Add1(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var clientForRemoving = GridName.SelectedItems.Cast<name>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {clientForRemoving.Count()} элементов", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    pro12Entities6.GetContext().name.RemoveRange(clientForRemoving);
                    pro12Entities6.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    GridName.ItemsSource = pro12Entities6.GetContext().name.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void CmbCabinet_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void TxtFirstName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filter();
        }

        public void Filter()
        {
            List<name> clients = pro12Entities6.GetContext().name.ToList();

            if (CmbCabinet.SelectedItem == null && TxtFirstName.Text == "")
            {
                return;
            }

            if (CmbCabinet.SelectedItem != null)
            {
                Department CurrentGender = CmbCabinet.SelectedItem as Department;
                clients = clients.Where(z => z.Department == CurrentGender).ToList();
            }

            clients = clients.Where(z => z.LastNmae.ToLower().Contains(TxtFirstName.Text.ToLower())).ToList();
            GridName.ItemsSource = clients;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BtnReport_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ReportWel());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            CmbCabinet.SelectedValue = null;
            TxtFirstName.Text = null;

            GridName.ItemsSource = pro12Entities6.GetContext().name.ToList();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Affairs());
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Purch());
        }
    }
}
