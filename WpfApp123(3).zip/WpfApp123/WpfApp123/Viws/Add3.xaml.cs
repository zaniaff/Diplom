﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp123.Viws
{
    /// <summary>
    /// Логика взаимодействия для Add3.xaml
    /// </summary>
    public partial class Add3 : Page
    {
        private Djob _currentDjob = new Djob();
        public Add3(Djob selectedDjob)
        {
            InitializeComponent();

            if (selectedDjob != null)
                _currentDjob = selectedDjob;


            DataContext = _currentDjob;
            ComboDepart.ItemsSource = pro12Entities6.GetContext().Department.ToList();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentDjob.Deal))
                errors.AppendLine("error");
            if (_currentDjob.Deal == null)
                errors.AppendLine("error");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentDjob.id == 0)
                pro12Entities6.GetContext().Djob.Add(_currentDjob);

            try
            {
                pro12Entities6.GetContext().SaveChanges();
                MessageBox.Show("информация сохранена");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
