﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp123.Viws
{
    /// <summary>
    /// Логика взаимодействия для Add1.xaml
    /// </summary>
    public partial class Add1 : Page
    {
        private name _currentNames = new name();
        public Add1(name selectedName)
        {
            InitializeComponent();

            if (selectedName != null)
                _currentNames = selectedName;

            

            DataContext = _currentNames;
            ComboDepart.ItemsSource = pro12Entities6.GetContext().Department.ToList();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentNames.Name1))
                errors.AppendLine("error");
            if (_currentNames.Name1 == null)
                errors.AppendLine("error");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentNames.id == 0)
                pro12Entities6.GetContext().name.Add(_currentNames);

            try
            {
                pro12Entities6.GetContext().SaveChanges();
                MessageBox.Show("информация сохранена");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
