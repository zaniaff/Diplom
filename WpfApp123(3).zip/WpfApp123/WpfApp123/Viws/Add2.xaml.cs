﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp123.Viws
{
    /// <summary>
    /// Логика взаимодействия для Add2.xaml
    /// </summary>
    public partial class Add2 : Page
    {
        private Zakaz _currentZakaz = new Zakaz();
        public Add2(Zakaz selectedZakaz)
        {
            InitializeComponent();

            if (selectedZakaz != null)
                _currentZakaz = selectedZakaz;

            DataContext = _currentZakaz;
            ComboDepart.ItemsSource = pro12Entities6.GetContext().Department.ToList();
            ComboStat.ItemsSource = pro12Entities6.GetContext().Status.ToList();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentZakaz.Title))
                errors.AppendLine("error");
            if (_currentZakaz.Title == null)
                errors.AppendLine("error");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentZakaz.id == 0)
                pro12Entities6.GetContext().Zakaz.Add(_currentZakaz);

            try
            {
                pro12Entities6.GetContext().SaveChanges();
                MessageBox.Show("информация сохранена");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
